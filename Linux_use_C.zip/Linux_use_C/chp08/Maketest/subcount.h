#ifndef _SUBCOUNT__
#define _SUBCOUNT__
int subcount(int value,int count);
#endif

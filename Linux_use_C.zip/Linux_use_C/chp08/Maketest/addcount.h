#ifndef _ADDCOUNT__
#define _ADDCOUNT__
int addcount(int value,int count);
#endif

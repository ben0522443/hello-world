#ifndef _FUNC1_H_
#define _FUNC1_H_
void func1print();
#endif

#include <stdio.h>
#include "func1.h"
void func1print()
{
	printf(" This is func1 print!\n");
}

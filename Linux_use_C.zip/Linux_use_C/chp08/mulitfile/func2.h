#ifndef _FUNC2_H_
#define _FUNC2_H_
void func2print();
#endif

#include "func1.h"
#include "func2.h"

int main()
{
	func1print();

	func2print();

	return 0;
}

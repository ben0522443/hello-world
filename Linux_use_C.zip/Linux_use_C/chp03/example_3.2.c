
#include <stdio.h>
#define M (x*y+z) 

void  main()
{
int sum=0; 
int x=2,y=3,z=4;
sum=M+9*M +M*M; 
printf("sum=%d\n",sum);
}


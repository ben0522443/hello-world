
#include <stdio.h>
void main(void)
{
int height,width,s;
scanf("%d,%d",& height,& width);//��J�x�ΰ��P�e
s = height *width;
printf("s=%d",s);
}

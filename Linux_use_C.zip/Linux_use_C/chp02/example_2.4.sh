#!/bin/sh
echo "input your name and age:"
read name age
echo "name is:"$name
echo "age is:"$age

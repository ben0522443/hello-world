#!/bin/sh
function printName()
{
  echo my name is tom!!!
}

printName


#!/bin/sh
echo "PWD:"$PWD
echo "path:"$PATH
echo "Logname:"$LOGNAME
echo "Shell:"$SHELL
echo "HOME:"$HOME

#!/bin/sh
function printName()
{
  echo $0
  echo $2
}

printName tom jim

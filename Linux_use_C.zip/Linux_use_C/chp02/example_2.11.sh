#!/bin/sh
name=(tom jim my test)
for i in ${name[*]}
do 
 echo $i
done

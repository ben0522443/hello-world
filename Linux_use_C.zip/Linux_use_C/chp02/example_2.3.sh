#!/bin/sh
name=tom
echo $name
echo ${name}test
echo test$name

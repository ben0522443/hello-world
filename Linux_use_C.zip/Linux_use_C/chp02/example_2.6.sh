#!/bin/sh
name=(tom jim jane test)
echo "name set  is :"${name[*]}
echo "name set  is :"${name[@]}



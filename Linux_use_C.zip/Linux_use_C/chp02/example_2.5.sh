#!/bin/sh
name=(tom jim jane test)
echo "name[0] is :"${name[0]}
echo "name[1] is :"${name[1]}
echo "name[2] is :"${name[2]}
echo "name[3] is :"${name[3]}

